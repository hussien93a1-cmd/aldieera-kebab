
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { AppView, Product, Order, OrderItem, Variant } from './types';
import { ICONS, NOTIFICATION_SOUND_URL } from './constants';
import Storefront from './components/Storefront';
import Dashboard from './components/Dashboard';
import AdminLogin from './components/AdminLogin';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('store');
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('products');
    return saved ? JSON.parse(saved) : [];
  });
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('orders');
    return saved ? JSON.parse(saved) : [];
  });
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [isNewOrder, setIsNewOrder] = useState(false);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('orders', JSON.stringify(orders));
  }, [orders]);

  // Audio notification logic
  const playNotification = useCallback(() => {
    const audio = new Audio(NOTIFICATION_SOUND_URL);
    audio.volume = 1.0; // Ensure loud notification
    audio.play().catch(e => console.error("Audio playback blocked. User interaction required first.", e));
  }, []);

  // Listen for orders arriving in the same tab
  useEffect(() => {
    if (isNewOrder) {
      playNotification();
      setIsNewOrder(false);
    }
  }, [isNewOrder, playNotification]);

  // Handle cross-tab order synchronization (e.g. Admin sees order from another tab)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'orders' && e.newValue) {
        try {
          const oldOrders = JSON.parse(e.oldValue || '[]');
          const newOrders = JSON.parse(e.newValue);
          
          if (newOrders.length > oldOrders.length) {
            // New order detected from another tab
            playNotification();
            setOrders(newOrders); // Update current tab state
          }
        } catch (err) {
          console.error("Error parsing storage change", err);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [playNotification]);

  const addOrder = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
    setIsNewOrder(true);
  };

  const handleAddToCart = (product: Product, variant: Variant) => {
    const item: OrderItem = {
      cartId: Math.random().toString(36).substring(7),
      productId: product.id,
      variantId: variant.id,
      productName: product.name,
      variantName: variant.name,
      price: variant.price,
      cost: variant.cost,
    };
    setCart(prev => [...prev, item]);
  };

  const handleRemoveFromCart = (cartId: string) => {
    setCart(prev => prev.filter(item => item.cartId !== cartId));
  };

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-gray-200 px-4 py-3 flex justify-between items-center">
        <div className="flex items-center gap-2">
           <h1 className="text-xl font-extrabold text-orange-600">كباب الديرة</h1>
        </div>
        <div className="flex gap-2">
          {view === 'store' ? (
            <button 
              onClick={() => setView('login')}
              className="p-2 rounded-full hover:bg-orange-100 text-orange-600 transition-colors"
              title="لوحة التحكم"
            >
              <ICONS.Dashboard />
            </button>
          ) : (
            <button 
              onClick={() => setView('store')}
              className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors text-sm font-bold"
            >
              العودة للمتجر
            </button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-x-hidden">
        {view === 'store' && (
          <Storefront 
            products={products} 
            onAddToCart={handleAddToCart}
            cart={cart}
            onRemoveFromCart={handleRemoveFromCart}
            onCompleteOrder={(order) => {
              addOrder(order);
              setCart([]);
            }}
          />
        )}
        {view === 'login' && (
          <AdminLogin onLogin={() => setView('admin')} />
        )}
        {view === 'admin' && (
          <Dashboard 
            products={products} 
            setProducts={setProducts} 
            orders={orders}
            setOrders={setOrders}
          />
        )}
      </main>

      {/* Persistent Cart Button for Mobile (Only in store view) */}
      {view === 'store' && cart.length > 0 && (
         <div className="md:hidden fixed bottom-6 left-6 right-6 z-50">
            {/* Logic handled inside Storefront to open cart drawer */}
         </div>
      )}
    </div>
  );
};

export default App;
