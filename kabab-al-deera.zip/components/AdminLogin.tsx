
import React, { useState } from 'react';

interface AdminLoginProps {
  onLogin: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === '1234') {
      onLogin();
    } else {
      setError('كلمة المرور غير صحيحة');
      setPassword('');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-xl border border-gray-100 p-8">
        <div className="text-center mb-8">
            <h2 className="text-2xl font-black text-gray-800">الدخول إلى لوحة التحكم</h2>
            <p className="text-gray-500 mt-2">يرجى إدخال كلمة المرور الافتراضية</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <input 
              autoFocus
              type="password"
              placeholder="••••"
              className="w-full text-center text-3xl tracking-widest px-4 py-4 rounded-2xl border-2 border-gray-100 focus:border-orange-500 focus:ring-0 outline-none transition-all"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
            {error && <p className="text-red-500 text-sm text-center mt-2 font-bold">{error}</p>}
          </div>
          
          <button 
            type="submit"
            className="w-full bg-orange-600 text-white font-black py-4 rounded-2xl text-xl hover:bg-orange-700 transition-transform active:scale-95"
          >
            دخول
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
