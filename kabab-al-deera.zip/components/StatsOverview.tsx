
import React, { useMemo } from 'react';
import { Order } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface StatsOverviewProps {
  orders: Order[];
}

interface ItemSales {
  productName: string;
  variantName: string;
  quantity: number;
  totalAmount: number;
}

const StatsOverview: React.FC<StatsOverviewProps> = ({ orders }) => {
  const stats = useMemo(() => {
    const totalSales = orders.reduce((sum, order) => sum + order.total, 0);
    const totalCost = orders.reduce((sum, order) => {
      return sum + order.items.reduce((itemSum, item) => itemSum + (item.cost || 0), 0);
    }, 0);
    const totalProfit = totalSales - totalCost;
    const totalOrders = orders.length;

    // Group sales by day (last 7 days)
    const last7Days = [...Array(7)].map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      return d.toISOString().split('T')[0];
    }).reverse();

    const chartData = last7Days.map(date => {
      const dayOrders = orders.filter(o => o.createdAt.startsWith(date));
      return {
        name: date,
        total: dayOrders.reduce((s, o) => s + o.total, 0),
      };
    });

    // Item-wise sales report
    const itemSalesMap: Record<string, ItemSales> = {};
    orders.forEach(order => {
      order.items.forEach(item => {
        const key = `${item.productId}-${item.variantId}`;
        if (!itemSalesMap[key]) {
          itemSalesMap[key] = {
            productName: item.productName,
            variantName: item.variantName,
            quantity: 0,
            totalAmount: 0,
          };
        }
        itemSalesMap[key].quantity += 1;
        itemSalesMap[key].totalAmount += item.price;
      });
    });

    const itemSalesList = Object.values(itemSalesMap).sort((a, b) => b.totalAmount - a.totalAmount);

    return { totalSales, totalProfit, totalOrders, chartData, itemSalesList };
  }, [orders]);

  return (
    <div className="space-y-8">
      {/* Top Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-orange-50 p-6 rounded-2xl border border-orange-100">
          <p className="text-sm text-orange-600 font-bold mb-1">إجمالي المبيعات</p>
          <p className="text-3xl font-black text-orange-900">{stats.totalSales} د.ع</p>
        </div>
        <div className="bg-green-50 p-6 rounded-2xl border border-green-100">
          <p className="text-sm text-green-600 font-bold mb-1">إجمالي الأرباح</p>
          <p className="text-3xl font-black text-green-900">{stats.totalProfit} د.ع</p>
        </div>
        <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
          <p className="text-sm text-blue-600 font-bold mb-1">عدد الطلبات</p>
          <p className="text-3xl font-black text-blue-900">{stats.totalOrders}</p>
        </div>
      </div>

      {/* Sales Chart */}
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <h3 className="text-lg font-bold mb-6 text-gray-800">مبيعات آخر 7 أيام</h3>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stats.chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
              <Tooltip
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                cursor={{ fill: '#f8fafc' }}
              />
              <Bar dataKey="total" fill="#f97316" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Item-wise Sales Report */}
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-gray-800">تقارير المبيعات حسب الصنف</h3>
          <span className="text-xs bg-gray-100 text-gray-500 px-3 py-1 rounded-full font-bold">مفصل حسب الكمية والمبلغ</span>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead>
              <tr className="text-gray-400 text-xs uppercase border-b border-gray-50">
                <th className="px-4 py-3 font-bold">المنتج</th>
                <th className="px-4 py-3 font-bold">المتغير</th>
                <th className="px-4 py-3 font-bold text-center">الكمية المباعة</th>
                <th className="px-4 py-3 font-bold text-left">إجمالي المبيعات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {stats.itemSalesList.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-gray-400 text-sm">لا توجد بيانات مبيعات حالياً</td>
                </tr>
              ) : (
                stats.itemSalesList.map((item, idx) => (
                  <tr key={idx} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-4 py-4 font-bold text-gray-800">{item.productName}</td>
                    <td className="px-4 py-4 text-sm text-gray-500">{item.variantName}</td>
                    <td className="px-4 py-4 text-center">
                      <span className="inline-block bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-black">
                        {item.quantity}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-left font-black text-orange-600">
                      {item.totalAmount} د.ع
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {stats.itemSalesList.length > 0 && (
              <tfoot>
                <tr className="bg-gray-50 font-black text-gray-800">
                  <td colSpan={2} className="px-4 py-4 text-left">المجموع:</td>
                  <td className="px-4 py-4 text-center text-orange-700">
                    {stats.itemSalesList.reduce((acc, curr) => acc + curr.quantity, 0)}
                  </td>
                  <td className="px-4 py-4 text-left text-orange-600">
                    {stats.totalSales} د.ع
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

export default StatsOverview;
