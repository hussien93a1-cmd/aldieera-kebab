
import React, { useState } from 'react';
import { Product, Variant, OrderItem, Order } from '../types';
import { ICONS } from '../constants';

interface StorefrontProps {
  products: Product[];
  onAddToCart: (product: Product, variant: Variant) => void;
  cart: OrderItem[];
  onRemoveFromCart: (cartId: string) => void;
  onCompleteOrder: (order: Order) => void;
}

const Storefront: React.FC<StorefrontProps> = ({ 
  products, 
  onAddToCart, 
  cart, 
  onRemoveFromCart, 
  onCompleteOrder 
}) => {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [customerInfo, setCustomerInfo] = useState({ name: '', phone: '', address: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    if (!customerInfo.name || !customerInfo.phone || !customerInfo.address) {
        alert("يرجى ملء جميع بيانات الزبون");
        return;
    }

    setIsSubmitting(true);

    const newOrder: Order = {
      id: Math.random().toString(36).substring(7).toUpperCase(),
      customerName: customerInfo.name,
      phone: customerInfo.phone,
      address: customerInfo.address,
      items: cart,
      total,
      createdAt: new Date().toISOString(),
    };

    // Construct WhatsApp message
    let message = `*طلب جديد من كباب الديرة*\n\n`;
    message += `👤 *الاسم:* ${newOrder.customerName}\n`;
    message += `📞 *الهاتف:* ${newOrder.phone}\n`;
    message += `📍 *العنوان:* ${newOrder.address}\n\n`;
    message += `📋 *الطلبات:*\n`;
    
    // List each item as a separate line as requested
    cart.forEach((item, index) => {
      message += `${index + 1}. ${item.productName} - ${item.variantName} (${item.price} د.ع)\n`;
    });

    message += `\n💰 *المجموع الكلي:* ${total} د.ع`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/9647800000000?text=${encodedMessage}`; // Replace with actual number if needed

    // Save locally
    onCompleteOrder(newOrder);

    // Open WhatsApp
    window.open(whatsappUrl, '_blank');
    
    // Reset
    setCustomerInfo({ name: '', phone: '', address: '' });
    setIsCartOpen(false);
    setIsSubmitting(false);
    alert("تم إرسال الطلب بنجاح!");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 relative">
      <div className="flex flex-col md:flex-row gap-8">
        
        {/* Product Grid */}
        <div className="flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.length === 0 ? (
                <div className="col-span-full py-20 text-center text-gray-500">
                    <p className="text-xl">لا توجد منتجات معروضة حالياً.</p>
                </div>
            ) : (
                products.map(product => (
                  <div key={product.id} className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow overflow-hidden flex flex-col border border-gray-100">
                    <img 
                      src={product.imageUrl || `https://picsum.photos/seed/${product.id}/400/300`} 
                      alt={product.name}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-4 flex-1 flex flex-col">
                      <h3 className="text-lg font-bold text-gray-800">{product.name}</h3>
                      <p className="text-sm text-gray-500 mb-4 line-clamp-2">{product.description}</p>
                      
                      <div className="mt-auto space-y-2">
                        {product.variants.map(variant => (
                          <button
                            key={variant.id}
                            onClick={() => onAddToCart(product, variant)}
                            className="w-full flex justify-between items-center bg-gray-50 hover:bg-orange-50 p-3 rounded-xl transition-colors group"
                          >
                            <span className="text-sm font-medium text-gray-700 group-hover:text-orange-700">{variant.name}</span>
                            <div className="flex items-center gap-2">
                                <span className="text-orange-600 font-bold">{variant.price} د.ع</span>
                                <span className="bg-orange-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                                    </svg>
                                </span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))
            )}
          </div>
        </div>

        {/* Sidebar Cart - Desktop */}
        <div className="hidden lg:block w-80 shrink-0">
          <div className="sticky top-24 bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
            <div className="p-4 bg-orange-600 text-white flex justify-between items-center">
              <h2 className="font-bold flex items-center gap-2">
                <ICONS.Cart />
                سلة الطلبات ({cart.length})
              </h2>
            </div>
            
            <div className="p-4 max-h-[400px] overflow-y-auto">
              {cart.length === 0 ? (
                <p className="text-center text-gray-400 py-8">السلة فارغة</p>
              ) : (
                <div className="space-y-3">
                  {cart.map(item => (
                    <div key={item.cartId} className="flex justify-between items-start border-b border-gray-50 pb-2">
                      <div className="flex-1">
                        <p className="font-bold text-sm text-gray-800">{item.productName}</p>
                        <p className="text-xs text-gray-500">{item.variantName}</p>
                      </div>
                      <div className="text-left flex flex-col items-end">
                        <span className="text-orange-600 font-bold text-sm">{item.price} د.ع</span>
                        <button 
                          onClick={() => onRemoveFromCart(item.cartId)}
                          className="text-red-500 text-[10px] hover:underline"
                        >حذف</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-4 border-t border-gray-100 bg-gray-50">
                <div className="flex justify-between items-center mb-4">
                  <span className="font-bold text-gray-700">المجموع:</span>
                  <span className="text-xl font-black text-orange-600">{total} د.ع</span>
                </div>
                
                <form onSubmit={handleCheckout} className="space-y-3">
                  <input 
                    required
                    placeholder="اسم الزبون"
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                    value={customerInfo.name}
                    onChange={e => setCustomerInfo(p => ({...p, name: e.target.value}))}
                  />
                  <input 
                    required
                    type="tel"
                    placeholder="رقم الهاتف"
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                    value={customerInfo.phone}
                    onChange={e => setCustomerInfo(p => ({...p, phone: e.target.value}))}
                  />
                  <textarea 
                    required
                    placeholder="العنوان الكامل"
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                    rows={2}
                    value={customerInfo.address}
                    onChange={e => setCustomerInfo(p => ({...p, address: e.target.value}))}
                  />
                  <button 
                    disabled={isSubmitting}
                    className="w-full bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <ICONS.WhatsApp />
                    {isSubmitting ? 'جاري الإرسال...' : 'إرسال الطلب عبر واتساب'}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Floating Cart Trigger - Mobile */}
      {cart.length > 0 && (
        <button 
          onClick={() => setIsCartOpen(true)}
          className="lg:hidden fixed bottom-6 left-6 right-6 bg-orange-600 text-white p-4 rounded-2xl shadow-2xl flex justify-between items-center z-40 animate-bounce"
        >
          <div className="flex items-center gap-3">
            <ICONS.Cart />
            <span className="font-bold">سلة المشتريات ({cart.length})</span>
          </div>
          <span className="font-black text-lg">{total} د.ع</span>
        </button>
      )}

      {/* Mobile Cart Drawer Overlay */}
      {isCartOpen && (
        <div className="lg:hidden fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsCartOpen(false)} />
          <div className="absolute bottom-0 inset-x-0 bg-white rounded-t-3xl max-h-[90vh] overflow-y-auto flex flex-col p-6 shadow-2xl transition-transform duration-300 transform translate-y-0">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-black text-gray-800">تفاصيل الطلب</h2>
                <button onClick={() => setIsCartOpen(false)} className="text-gray-400 p-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <div className="space-y-4 mb-8">
                {cart.map(item => (
                    <div key={item.cartId} className="flex justify-between items-center bg-gray-50 p-4 rounded-2xl">
                        <div>
                            <p className="font-bold text-gray-800">{item.productName}</p>
                            <p className="text-sm text-gray-500">{item.variantName}</p>
                        </div>
                        <div className="flex items-center gap-4">
                            <span className="font-bold text-orange-600">{item.price} د.ع</span>
                            <button 
                                onClick={() => onRemoveFromCart(item.cartId)}
                                className="bg-red-100 text-red-600 p-2 rounded-full"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            <div className="bg-orange-50 p-6 rounded-2xl mb-8">
                <div className="flex justify-between items-center mb-6">
                  <span className="text-lg font-bold text-gray-700">المجموع الكلي:</span>
                  <span className="text-3xl font-black text-orange-600">{total} د.ع</span>
                </div>
                
                <form onSubmit={handleCheckout} className="space-y-4">
                    <input 
                      required
                      placeholder="اسم الزبون"
                      className="w-full px-5 py-3 rounded-xl border-2 border-orange-100 focus:ring-2 focus:ring-orange-500 focus:border-transparent text-lg"
                      value={customerInfo.name}
                      onChange={e => setCustomerInfo(p => ({...p, name: e.target.value}))}
                    />
                    <input 
                      required
                      type="tel"
                      placeholder="رقم الهاتف"
                      className="w-full px-5 py-3 rounded-xl border-2 border-orange-100 focus:ring-2 focus:ring-orange-500 focus:border-transparent text-lg"
                      value={customerInfo.phone}
                      onChange={e => setCustomerInfo(p => ({...p, phone: e.target.value}))}
                    />
                    <textarea 
                      required
                      placeholder="العنوان الكامل"
                      className="w-full px-5 py-3 rounded-xl border-2 border-orange-100 focus:ring-2 focus:ring-orange-500 focus:border-transparent text-lg"
                      rows={3}
                      value={customerInfo.address}
                      onChange={e => setCustomerInfo(p => ({...p, address: e.target.value}))}
                    />
                    <button 
                      disabled={isSubmitting}
                      className="w-full bg-green-600 text-white font-bold py-4 rounded-2xl text-xl hover:bg-green-700 transition-colors flex items-center justify-center gap-3 shadow-lg"
                    >
                      <ICONS.WhatsApp />
                      {isSubmitting ? 'جاري الإرسال...' : 'تأكيد الطلب وفتح واتساب'}
                    </button>
                </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Storefront;
