
import React, { useState } from 'react';
import { Order } from '../types';

interface InvoicesTableProps {
  orders: Order[];
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
}

const InvoicesTable: React.FC<InvoicesTableProps> = ({ orders, setOrders }) => {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const deleteOrder = (id: string) => {
    if (confirm("هل أنت متأكد من حذف هذا الطلب؟")) {
      setOrders(prev => prev.filter(o => o.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      <div className="overflow-x-auto">
        <table className="w-full text-right border-collapse">
          <thead>
            <tr className="bg-gray-50 text-gray-500 text-sm uppercase">
              <th className="px-4 py-3 border-b border-gray-100">رقم الطلب</th>
              <th className="px-4 py-3 border-b border-gray-100">الزبون</th>
              <th className="px-4 py-3 border-b border-gray-100">التاريخ</th>
              <th className="px-4 py-3 border-b border-gray-100">المجموع</th>
              <th className="px-4 py-3 border-b border-gray-100">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {orders.length === 0 ? (
                <tr>
                    <td colSpan={5} className="py-12 text-center text-gray-400">لا توجد فواتير لعرضها</td>
                </tr>
            ) : (
                orders.map(order => (
                  <tr key={order.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-4 py-4 font-bold text-gray-700">#{order.id}</td>
                    <td className="px-4 py-4">
                        <div className="text-sm font-bold text-gray-800">{order.customerName}</div>
                        <div className="text-xs text-gray-500">{order.phone}</div>
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-500">
                        {new Date(order.createdAt).toLocaleString('ar-EG')}
                    </td>
                    <td className="px-4 py-4 font-black text-orange-600">
                        {order.total} د.ع
                    </td>
                    <td className="px-4 py-4 flex gap-2">
                        <button 
                            onClick={() => setSelectedOrder(order)}
                            className="bg-gray-100 hover:bg-gray-200 p-2 rounded-lg text-gray-600 transition-colors"
                        >
                            تفاصيل
                        </button>
                        <button 
                            onClick={() => deleteOrder(order.id)}
                            className="bg-red-50 hover:bg-red-100 p-2 rounded-lg text-red-600 transition-colors"
                        >
                            حذف
                        </button>
                    </td>
                  </tr>
                ))
            )}
          </tbody>
        </table>
      </div>

      {/* Invoice Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setSelectedOrder(null)} />
            <div className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in duration-200">
                <div className="p-6 bg-orange-600 text-white flex justify-between items-center">
                    <h2 className="text-xl font-black">تفاصيل الفاتورة #{selectedOrder.id}</h2>
                    <button onClick={() => setSelectedOrder(null)} className="text-white/80 hover:text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
                
                <div className="p-6">
                    <div className="grid grid-cols-2 gap-4 mb-8">
                        <div>
                            <p className="text-xs text-gray-400 font-bold uppercase mb-1">معلومات الزبون</p>
                            <p className="font-bold text-gray-800">{selectedOrder.customerName}</p>
                            <p className="text-sm text-gray-600">{selectedOrder.phone}</p>
                        </div>
                        <div className="text-left">
                            <p className="text-xs text-gray-400 font-bold uppercase mb-1">العنوان</p>
                            <p className="text-sm text-gray-800">{selectedOrder.address}</p>
                        </div>
                    </div>

                    <div className="border border-gray-100 rounded-2xl overflow-hidden mb-8">
                        <table className="w-full text-right">
                            <thead className="bg-gray-50 border-b border-gray-100">
                                <tr>
                                    <th className="px-4 py-2 text-xs font-bold text-gray-500">المنتج</th>
                                    <th className="px-4 py-2 text-xs font-bold text-gray-500 text-left">السعر</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50">
                                {selectedOrder.items.map((item, idx) => (
                                    <tr key={item.cartId + idx}>
                                        <td className="px-4 py-3">
                                            <p className="font-bold text-sm text-gray-800">{item.productName}</p>
                                            <p className="text-xs text-gray-500">{item.variantName}</p>
                                        </td>
                                        <td className="px-4 py-3 text-left font-bold text-orange-600">
                                            {item.price} د.ع
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    <div className="flex justify-between items-center bg-gray-50 p-6 rounded-2xl">
                        <span className="text-xl font-bold text-gray-700">المجموع الكلي:</span>
                        <span className="text-3xl font-black text-orange-600">{selectedOrder.total} د.ع</span>
                    </div>
                </div>
                
                <div className="p-6 bg-gray-100 flex justify-end gap-3">
                    <button 
                        onClick={() => window.print()}
                        className="px-6 py-2 bg-white border border-gray-200 rounded-xl font-bold text-gray-600 hover:bg-gray-50"
                    >
                        طباعة
                    </button>
                    <button 
                        onClick={() => setSelectedOrder(null)}
                        className="px-6 py-2 bg-gray-800 text-white rounded-xl font-bold"
                    >
                        إغلاق
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default InvoicesTable;
