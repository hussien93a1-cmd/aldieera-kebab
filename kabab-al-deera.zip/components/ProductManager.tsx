
import React, { useState } from 'react';
import { Product, Variant } from '../types';

interface ProductManagerProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
}

const ProductManager: React.FC<ProductManagerProps> = ({ products, setProducts }) => {
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [tempVariants, setTempVariants] = useState<Variant[]>([]);

  const openAddProduct = () => {
    setEditingProduct({
        id: Math.random().toString(36).substring(7),
        name: '',
        description: '',
        imageUrl: '',
        variants: []
    });
    setTempVariants([{ id: Math.random().toString(36).substring(7), name: 'سادة', price: 0, cost: 0 }]);
  };

  const addTempVariant = () => {
    setTempVariants(prev => [...prev, { id: Math.random().toString(36).substring(7), name: '', price: 0, cost: 0 }]);
  };

  const removeTempVariant = (id: string) => {
    setTempVariants(prev => prev.filter(v => v.id !== id));
  };

  const saveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    const finalProduct = {
        ...editingProduct,
        variants: tempVariants.filter(v => v.name && v.price >= 0)
    } as Product;

    if (products.find(p => p.id === finalProduct.id)) {
        setProducts(prev => prev.map(p => p.id === finalProduct.id ? finalProduct : p));
    } else {
        setProducts(prev => [...prev, finalProduct]);
    }
    
    setEditingProduct(null);
    setTempVariants([]);
  };

  const deleteProduct = (id: string) => {
      if(confirm("حذف المنتج نهائياً؟")) {
          setProducts(prev => prev.filter(p => p.id !== id));
      }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-800">قائمة المنتجات ({products.length})</h2>
        <button 
            onClick={openAddProduct}
            className="bg-orange-600 text-white px-6 py-2 rounded-xl font-bold hover:bg-orange-700 transition-colors shadow-lg shadow-orange-200"
        >
            + إضافة منتج جديد
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map(product => (
            <div key={product.id} className="border border-gray-100 rounded-2xl p-4 bg-white shadow-sm flex flex-col group">
                <img src={product.imageUrl || 'https://picsum.photos/seed/kabab/200/150'} className="w-full h-32 object-cover rounded-xl mb-3" />
                <h3 className="font-bold text-gray-800">{product.name}</h3>
                <p className="text-xs text-gray-400 mb-4">{product.variants.length} متغيرات</p>
                <div className="flex gap-2 mt-auto">
                    <button 
                        onClick={() => {
                            setEditingProduct(product);
                            setTempVariants(product.variants);
                        }}
                        className="flex-1 bg-gray-100 text-gray-600 py-2 rounded-lg font-bold hover:bg-gray-200 transition-colors"
                    >
                        تعديل
                    </button>
                    <button 
                        onClick={() => deleteProduct(product.id)}
                        className="bg-red-50 text-red-600 p-2 rounded-lg hover:bg-red-100"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                    </button>
                </div>
            </div>
        ))}
      </div>

      {/* Add/Edit Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setEditingProduct(null)} />
            <div className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
                <div className="p-6 bg-orange-600 text-white flex justify-between items-center">
                    <h2 className="text-xl font-bold">{editingProduct.name ? 'تعديل منتج' : 'إضافة منتج جديد'}</h2>
                    <button onClick={() => setEditingProduct(null)}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
                
                <form onSubmit={saveProduct} className="flex-1 overflow-y-auto p-6 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                            <label className="text-xs font-bold text-gray-500">اسم المنتج</label>
                            <input 
                                required
                                className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:bg-white outline-none"
                                value={editingProduct.name}
                                onChange={e => setEditingProduct(p => ({...p!, name: e.target.value}))}
                            />
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs font-bold text-gray-500">رابط الصورة (اختياري)</label>
                            <input 
                                className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:bg-white outline-none"
                                value={editingProduct.imageUrl}
                                onChange={e => setEditingProduct(p => ({...p!, imageUrl: e.target.value}))}
                            />
                        </div>
                        <div className="md:col-span-2 space-y-1">
                            <label className="text-xs font-bold text-gray-500">الوصف</label>
                            <textarea 
                                className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:bg-white outline-none"
                                value={editingProduct.description}
                                onChange={e => setEditingProduct(p => ({...p!, description: e.target.value}))}
                            />
                        </div>
                    </div>

                    <div className="space-y-3">
                        <div className="flex justify-between items-center">
                            <h3 className="text-sm font-black text-gray-700">المتغيرات (الأسعار والتكاليف)</h3>
                            <button 
                                type="button" 
                                onClick={addTempVariant}
                                className="text-orange-600 font-bold text-xs bg-orange-50 px-3 py-1 rounded-full border border-orange-100"
                            >
                                + إضافة متغير
                            </button>
                        </div>
                        
                        <div className="space-y-3">
                            {tempVariants.map((variant, index) => (
                                <div key={variant.id} className="bg-gray-50 p-4 rounded-2xl grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
                                    <div className="space-y-1">
                                        <label className="text-[10px] text-gray-400 font-bold">الاسم (مثلاً: ربع، كيلو)</label>
                                        <input 
                                            required
                                            className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm"
                                            value={variant.name}
                                            onChange={e => {
                                                const newV = [...tempVariants];
                                                newV[index].name = e.target.value;
                                                setTempVariants(newV);
                                            }}
                                        />
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-[10px] text-gray-400 font-bold">سعر البيع</label>
                                        <input 
                                            required
                                            type="number"
                                            className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm"
                                            value={variant.price}
                                            onChange={e => {
                                                const newV = [...tempVariants];
                                                newV[index].price = Number(e.target.value);
                                                setTempVariants(newV);
                                            }}
                                        />
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-[10px] text-gray-400 font-bold">تكلفة المنتج</label>
                                        <input 
                                            required
                                            type="number"
                                            className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm"
                                            value={variant.cost}
                                            onChange={e => {
                                                const newV = [...tempVariants];
                                                newV[index].cost = Number(e.target.value);
                                                setTempVariants(newV);
                                            }}
                                        />
                                    </div>
                                    <button 
                                        type="button" 
                                        onClick={() => removeTempVariant(variant.id)}
                                        className="bg-red-100 text-red-600 px-3 py-2 rounded-lg text-xs font-bold hover:bg-red-200"
                                    >
                                        حذف
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                </form>

                <div className="p-6 bg-gray-50 flex gap-3">
                    <button 
                        type="button" 
                        onClick={() => setEditingProduct(null)}
                        className="flex-1 py-3 border border-gray-200 rounded-xl font-bold text-gray-500 hover:bg-white"
                    >
                        إلغاء
                    </button>
                    <button 
                        onClick={saveProduct}
                        className="flex-1 py-3 bg-orange-600 text-white rounded-xl font-bold hover:bg-orange-700 shadow-lg shadow-orange-100"
                    >
                        حفظ المنتج
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default ProductManager;
