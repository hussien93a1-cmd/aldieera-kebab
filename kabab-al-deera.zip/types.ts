
export interface Variant {
  id: string;
  name: string;
  price: number;
  cost: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  variants: Variant[];
}

export interface OrderItem {
  cartId: string;
  productId: string;
  variantId: string;
  productName: string;
  variantName: string;
  price: number;
  cost: number;
}

export interface Order {
  id: string;
  customerName: string;
  phone: string;
  address: string;
  items: OrderItem[];
  total: number;
  createdAt: string;
}

export type AppView = 'store' | 'admin' | 'login';
